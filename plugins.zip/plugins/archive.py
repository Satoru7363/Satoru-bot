# ════════════════════════════════════════
#  Satoru — م24: الأرشيف والإبلاغ
# ════════════════════════════════════════
import asyncio
from satoru import client
from telethon import events
from telethon.tl.functions.messages import ReportRequest
from telethon.tl.types import (
    InputReportReasonSpam, InputReportReasonViolence,
    InputReportReasonPornography, InputReportReasonOther
)
from database import db
from datetime import datetime


# ══════════════════════════════════════
#  الإبلاغ الداخلي (محلي)
# ══════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r"^\.بلاغ$"))
async def report_msg(event):
    await event.delete()
    reply = await event.get_reply_message()
    if not reply:
        return await event.respond("يجب الرد على الرسالة المراد الإبلاغ عنها")

    bid    = str(len(db.smembers("reports")) + 1)
    sender = reply.sender_id
    text   = reply.text or "[وسيطة]"
    ts     = datetime.now().strftime("%Y-%m-%d %H:%M")

    db.set(f"report:{bid}", {"id": bid, "sender": sender, "text": text[:300], "time": ts})
    db.sadd("reports", bid)
    await event.respond(
        f"**تم حفظ البلاغ #{bid}**\n\n"
        f"  من    :  `{sender}`\n"
        f"  وقت   :  {ts}"
    )


@client.on(events.NewMessage(outgoing=True, pattern=r"^\.بلاغات$"))
async def list_reports(event):
    await event.delete()
    ids = db.smembers("reports")
    if not ids:
        return await event.respond("لا توجد بلاغات")
    text = "**البلاغات:**\n\n"
    for rid in sorted(ids, key=int):
        r = db.get(f"report:{rid}", {})
        text += f"  `#{rid}`  |  `{r.get('sender','?')}`  |  {r.get('time','')}\n"
        text += f"  {r.get('text','')[:60]}\n\n"
    await event.respond(text[:4000])


@client.on(events.NewMessage(outgoing=True, pattern=r"^\.مسح البلاغات$"))
async def clear_reports(event):
    await event.delete()
    for rid in list(db.smembers("reports")):
        db.delete(f"report:{rid}")
    db.sdelete("reports")
    await event.respond("تم مسح جميع البلاغات")


# ══════════════════════════════════════
#  الإبلاغ لتيليجرام (داخلي حقيقي)
#  .ابلاغ [نوع] [عدد] [سرعة]
#  الأنواع: سبام، عنف، اباحي، اخرى
# ══════════════════════════════════════

REASON_MAP = {
    "سبام":   InputReportReasonSpam(),
    "عنف":    InputReportReasonViolence(),
    "اباحي":  InputReportReasonPornography(),
    "اخرى":   InputReportReasonOther(),
}


@client.on(events.NewMessage(outgoing=True, pattern=r"^\.ابلاغ ?(سبام|عنف|اباحي|اخرى)? ?(\d+)? ?(\d+)?$"))
async def telegram_report(event):
    """
    .ابلاغ [نوع] [عدد] [سرعة_بالثواني]
    مثال: .ابلاغ سبام 5 2
    يتطلب الرد على الرسالة أو المحادثة
    """
    await event.delete()
    reply = await event.get_reply_message()

    reason_key = event.pattern_match.group(1) or "سبام"
    count      = int(event.pattern_match.group(2) or 1)
    speed      = int(event.pattern_match.group(3) or 2)

    count = min(count, 20)
    speed = max(speed, 1)

    reason = REASON_MAP.get(reason_key, InputReportReasonSpam())

    if not reply:
        return await event.respond(
            "يجب الرد على الرسالة المراد الإبلاغ عنها\n\n"
            "الصيغة: `.ابلاغ [نوع] [عدد] [سرعة]`\n"
            "الأنواع: سبام | عنف | اباحي | اخرى"
        )

    msg = await event.respond(
        f"**جاري الإبلاغ...**\n\n"
        f"  النوع   :  {reason_key}\n"
        f"  العدد   :  {count}\n"
        f"  السرعة  :  {speed}s"
    )

    success = 0
    for i in range(count):
        try:
            chat = await client.get_entity(event.chat_id)
            await client(ReportRequest(
                peer=chat,
                id=[reply.id],
                reason=reason,
                message=f"إبلاغ #{i+1}"
            ))
            success += 1
        except Exception:
            pass
        if i < count - 1:
            await asyncio.sleep(speed)

    await msg.edit(
        f"**تم الإبلاغ**\n\n"
        f"  ناجح    :  {success}/{count}\n"
        f"  النوع   :  {reason_key}"
    )


# ══════════════════════════════════════
#  الأرشيف
# ══════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r"^\.ارشيف$"))
async def archive_msg(event):
    await event.delete()
    reply = await event.get_reply_message()
    if not reply:
        return await event.respond("يجب الرد على الرسالة المراد أرشفتها")
    aid  = str(len(db.smembers("archive")) + 1)
    text = reply.text or "[وسيطة]"
    ts   = datetime.now().strftime("%Y-%m-%d %H:%M")
    db.set(f"archive:{aid}", {"id": aid, "text": text[:500], "time": ts})
    db.sadd("archive", aid)
    await event.respond(f"**تم أرشفة الرسالة #{aid}**\n  الوقت  :  {ts}")


@client.on(events.NewMessage(outgoing=True, pattern=r"^\.ارشيفي$"))
async def list_archive(event):
    await event.delete()
    ids = db.smembers("archive")
    if not ids:
        return await event.respond("لا توجد رسائل مؤرشفة")
    text = "**أرشيفي:**\n\n"
    for aid in sorted(ids, key=int):
        a = db.get(f"archive:{aid}", {})
        text += f"  `#{aid}`  {a.get('time','')}\n  {a.get('text','')[:80]}\n\n"
    await event.respond(text[:4000])


# ══════════════════════════════════════
#  الملاحظات
# ══════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r"^\.ملاحظة (.+)$"))
async def add_note(event):
    await event.delete()
    text = event.pattern_match.group(1)
    nid  = str(len(db.smembers("notes")) + 1)
    ts   = datetime.now().strftime("%Y-%m-%d %H:%M")
    db.set(f"note:{nid}", {"id": nid, "text": text, "time": ts})
    db.sadd("notes", nid)
    await event.respond(f"**تم حفظ الملاحظة #{nid}**")


@client.on(events.NewMessage(outgoing=True, pattern=r"^\.ملاحظاتي$"))
async def list_notes(event):
    await event.delete()
    ids = db.smembers("notes")
    if not ids:
        return await event.respond("لا توجد ملاحظات")
    text = "**ملاحظاتي:**\n\n"
    for nid in sorted(ids, key=int):
        n = db.get(f"note:{nid}", {})
        text += f"  `#{nid}`  {n.get('text','')[:100]}\n"
    await event.respond(text[:4000])
